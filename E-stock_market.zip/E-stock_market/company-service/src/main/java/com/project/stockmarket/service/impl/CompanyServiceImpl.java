package com.project.stockmarket.service.impl;

import java.util.List;
import com.project.stockmarket.exceptions.CompanyNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.project.stockmarket.entity.Company;
import com.project.stockmarket.repository.CompanyRepository;
import com.project.stockmarket.service.CompanyService;

@Service
public class CompanyServiceImpl implements CompanyService {
    @Autowired
    private CompanyRepository companyRepository;

    @Override
    public Company registerCompany(Company companyDto) {
        Company companyEntity = companyRepository.findByCompanyCode(companyDto.getCompanyCode());
        if (companyEntity == null) {
            return companyRepository.save(companyDto);
        }else{
            throw new CompanyNotFoundException("The given company code is already exists");
        }
    }

    @Override
    public List<Company> getAll() {
        return companyRepository.findAll();
    }

    @Override
    public Company getCompanyByCode(String companyCode) {
        Company companyEntity = companyRepository.findByCompanyCode(companyCode);
        if (companyEntity != null) {
            return companyEntity;
        }else{
            throw new CompanyNotFoundException("The given company code is not found");
        }
    }

    @Override
    public boolean deleteCompanyByCode(String companyCode) {
        Company companyEntity = companyRepository.findByCompanyCode(companyCode);
        if (companyEntity != null) {
            companyRepository.deleteByCompanyCode(companyEntity.getCompanyCode());
            return true;
        } else {
            throw new CompanyNotFoundException("The given company code is not found");
        }
    }

}
