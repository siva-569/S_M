package com.project.stockmarket.service;

import java.util.List;
import com.project.stockmarket.entity.Company;


public interface CompanyService {
    public Company registerCompany(Company companyDto);
    public List<Company> getAll();
    public Company getCompanyByCode(String companyCode);
    public boolean deleteCompanyByCode(String companyCode);
}
