package com.project.stockmarket.model.exception;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ExceptionResponse {
	private String message;
	private Long timeStamp;
	private Integer status;
}
