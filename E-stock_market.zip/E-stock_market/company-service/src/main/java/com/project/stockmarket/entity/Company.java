package com.project.stockmarket.entity;

import io.swagger.annotations.ApiParam;
import lombok.Data;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
@Document("company")
public class Company {

    @Indexed(unique=true)
    @NotBlank(message = "companyCode is mandatory")
    @ApiParam(example = "JSWE", required = true)
    private String companyCode;
    @NotBlank(message = "companyName is mandatory")
    @ApiParam(example = "JSW Energy", required = true)
    private String companyName;
    @NotBlank(message = "Company CEO is mandatory")
    @ApiParam(example = "CEO", required = true)
    private String companyCEO;
    @NotNull(message = "Company Turnover is mandatory")
    @ApiParam(example = "100000000", required = true, value = "Company turnover should be greater than 10Cr")
    @DecimalMin(value = "100000001.00", message = "Company turnover should be greater than 10Cr")
    private Double companyTurnover;
    @NotBlank(message = "Company website is mandatory")
    @ApiParam(example = "www.jswe.com", required = true)
    private String companyWebsite;
    @NotBlank(message = "Company stock exchange is mandatory")
    @ApiParam(example = "BSE", required = true, value = "BSE/NSE")
    private String stockExchange;

}
