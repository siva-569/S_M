package com.project.stockmarket.service;

import java.util.List;
import com.project.stockmarket.entity.Stock;

public interface StockService {

    public Stock addStockDto(String companyCode, Double stockPrice);
    public List<Stock> getStockPrice(String companyCode,String startDate, String endDate);
}
