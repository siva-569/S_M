package com.project.stockmarket.controller;

import java.util.List;

import com.project.stockmarket.entity.Stock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.project.stockmarket.service.StockService;

import javax.validation.constraints.NotNull;

@RestController
@RequestMapping("/api/v1.0/market/stock")
public class StockController {

    @Autowired
    private StockService stockService;

    @PostMapping(value="/add/{companyCode}")
    public ResponseEntity<Stock> addStock(@PathVariable String companyCode, @RequestParam  @NotNull(message = "Stock price is mandatory") Double stockPrice) {
        return new ResponseEntity<>(stockService.addStockDto(companyCode, stockPrice),HttpStatus.CREATED);
    }

    @GetMapping(value="/get/{companyCode}/{startDate}/{endDate}")
    public ResponseEntity< List<Stock> >  getStockDetails(@PathVariable String companyCode, @PathVariable @DateTimeFormat(pattern="yyyy-MM-dd") String startDate, @PathVariable @DateTimeFormat(pattern="yyyy-MM-dd") String endDate) {
        return new ResponseEntity<>(stockService.getStockPrice(companyCode, startDate, endDate),HttpStatus.CREATED);
    }
}
