package com.project.stockmarket.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.project.stockmarket.entity.Company;
import com.project.stockmarket.exceptions.CompanyNotFoundException;
import com.project.stockmarket.repository.CompanyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.project.stockmarket.entity.Stock;
import com.project.stockmarket.repository.StockRepository;
import com.project.stockmarket.service.StockService;

@Service
public class StockServiceImpl implements StockService {
    @Autowired
    private StockRepository stockRepository;

    @Autowired
    private CompanyRepository companyRepository;

    @Override
    public Stock addStockDto(String companyCode, Double stockPrice) {
        Company companyEntity = companyRepository.findByCompanyCode(companyCode);
        if(companyEntity != null){
            Stock stockEntity = new Stock();
            stockEntity.setCompanyCode(companyCode);
            stockEntity.setStockPrice(stockPrice);
            String currentDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
            String currentTime = new SimpleDateFormat("HH:mm:ss").format(new Date());
            stockEntity.setDate(currentDate);
            stockEntity.setTime(currentTime);
            return stockRepository.save(stockEntity);
        }else{
            throw new CompanyNotFoundException("The given company code is not found");
        }
    }

    @Override
    public List<Stock> getStockPrice(String companyCode,String startDate, String endDate) {
        return stockRepository.findStocksByCompanyCodeAndDateBetween(companyCode, startDate, endDate);
    }
}
