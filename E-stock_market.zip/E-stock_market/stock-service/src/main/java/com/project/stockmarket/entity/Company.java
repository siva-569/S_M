package com.project.stockmarket.entity;

import lombok.Data;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
@Document("company")
public class Company {

    @Indexed(unique=true)
    private String companyCode;
    private String companyName;
    private String companyCEO;
    private Double companyTurnover;
    private String companyWebsite;
    private String stockExchange;

}
