package com.project.stockmarket.entity;

import javax.persistence.Id;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document("stock")
public class Stock {
    @Id
    private String id;
    private String companyCode;
    private String date;
    private String time;
    private Double stockPrice;

}
