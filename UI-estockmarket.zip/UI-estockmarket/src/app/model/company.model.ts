export class Company {
  companyCode: any
  companyName: any
  companyCEO: any
  companyTurnover: any
  companyWebsite: any
  stockExchange: any
}
