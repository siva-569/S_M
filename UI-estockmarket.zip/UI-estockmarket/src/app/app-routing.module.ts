import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ErrorComponent } from './error/error.component';
import { FindAStockComponent } from './stock-details/stock-details.component';

const routes: Routes = [
{ path: '', redirectTo:'stock-details', pathMatch: 'full' },
{ path: 'stock-details', component: FindAStockComponent },
{ path: '**', component: ErrorComponent },
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
