import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Company } from '../model/company.model';
import { Observable, throwError } from 'rxjs'

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    Authorization: 'my-auth-token'
  })
};

@Injectable({
  providedIn: 'root'
})
export class EStockMarketService {

  constructor(private http:HttpClient) { }

  private handleError(error: HttpErrorResponse) {
    let errorMessage: string = ''
    if (error.status === 0) {
      errorMessage = `An error occurred: ${error.error}`
    } else {
      errorMessage = `Backend returned code ${error.error.status}, reason: ${error.error.message}`
    }
    errorMessage += `\n Please try again.`
    return throwError(errorMessage);
  }

  public getAllCompanies() {
    return this.http.get("http://ec2-18-183-245-172.ap-northeast-1.compute.amazonaws.com:8092/company/getall" );
  }

  public doFindStocksBetweenDates(companyCode: any, startDate: Date, enddate: Date) {
    return this.http.get(`http://ec2-18-183-245-172.ap-northeast-1.compute.amazonaws.com:8092/stock/get/${companyCode}/${startDate}/${enddate}`)
  }
}

