import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { EStockMarketService } from '../service/e-stock-market.service';

@Component({
  selector: 'app-find-a-stock',
  templateUrl: './stock-details.component.html',
  styleUrls: ['./stock-details.component.css']
})
export class FindAStockComponent implements OnInit {

  responseStocks:any
  responseStock:any
  responseCompanies: any
  companyCode: any
  startDate: any
  pstartDate: any
  endDate: any
  pendDate: any
  min:any
  max:any
  avg:any
  comCode:any
  comName:any
  endNexday:any
  showInfo: boolean = false
  response:any
  message:any




  constructor(private service: EStockMarketService, public datepipe: DatePipe) { }

  ngOnInit(): void {
    this.service.getAllCompanies().subscribe((companies)=>{
      this.responseCompanies = companies
    })
  }

  public findStocksBetweenDates() {
    this.endDate =this.datepipe.transform(new Date(this.pendDate.year, this.pendDate.month - 1, this.pendDate.day), 'yyyy-MM-dd');
    this.startDate = this.datepipe.transform(new Date(this.pstartDate.year, this.pstartDate.month-1, this.pstartDate.day), 'yyyy-MM-dd');
    this.service.doFindStocksBetweenDates(this.companyCode, this.startDate, this.endDate)
    .subscribe((res)=>{
      this.response=res;
      console.log(res);
      if (this.response != null && (this.response.length >0 && this.companyCode == this.response[0].companyCode)) {
      const prices = [];
      for(let i=0; i< this.response.length; i++){
        prices.push(this.response[i].stockPrice)
      }
      this.responseStocks=this.response;
      this.comCode=this.companyCode;
      this.min = Math.min.apply(null, prices);
      this.max = Math.max.apply(null, prices);
      this.avg = (prices.reduce((a,b) => a + b, 0) / prices.length).toFixed(2);
      this.comName = this.response.companyName;
      this.showInfo = true;
      }else{
        this.showInfo = false;
        this.message="No result found";
      }
    })
  }
}
